﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace SimpleCalculator
{

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("Простой калькулятор (+,-,*,/)\n");

            bool continueWork = true;

            while (continueWork)
            {
                double num1 = ReadNumber("Введите первое число: ");
                double num2 = ReadNumber("Введите второе число: ");
                string operation = ChoosingAnOperation();
                Console.WriteLine();

                if (operation == "/" && num2 == 0)
                {
                    Console.WriteLine("Ошибка: деление на ноль невозможно!");
                    continueWork = AskContinue();
                    continue;
                }

                // Жёсткая проверка: если деление И второе число равно 0


                double result = Calculate(num1, num2, operation);
                Console.WriteLine($"Результат: {num1} {operation} {num2} = {result}");

                continueWork = AskContinue();
            }

        }

        static double ReadNumber(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();

                if (double.TryParse(input, out double number))
                {
                    return number;
                }
                else
                {
                    Console.WriteLine("Ошибка.Введите корректное число");
                }
            }
        }

        static string ChoosingAnOperation()
        {
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("Выберите операцию: ");
                Console.WriteLine("1. Сложение");
                Console.WriteLine("2. Вычетание");
                Console.WriteLine("3. Умножение");
                Console.WriteLine("4. Деление");
                Console.WriteLine();
                Console.Write("Ваш выбор: ");

                string? choice = Console.ReadLine().Trim();
                string? value = choice switch
                {
                    "1" => "+",
                    "2" => "-",
                    "3" => "*",
                    "4" => "/",
                    _ => null
                };

                if (value != null) return value;

                Console.WriteLine();
                Console.WriteLine("Ошибка. Введите число от 1 до 4 ");

            }


        }

        static double Calculate(double num1, double num2, string operation)
        {

            
            return operation switch
            {
                "+" => num1 + num2,
                "-" => num1 - num2,
                "*" => num1 * num2,
                "/" => num1 / num2,
                _ => 0
            };

        }

        static bool AskContinue()
        {
            while (true)
            {
                Console.WriteLine();
                Console.Write("Продолжить работу? Введите да/нет: ");
                string answer = Console.ReadLine().ToLower().Trim();
                Console.WriteLine();

                if (answer == "да")
                {
                    return true;
                }
                else if (answer == "нет")
                {
                    Console.WriteLine("Спасибо за использование калькулятора");
                    return false;
                }
                else
                {
                    Console.WriteLine("Введите корректное значение");
                }


            }


        }


    }
}

