﻿using System;

namespace IfElseExamples 
{
    public class Program
    {

        // константы для приведенных методов
        private const int LevelCompletion = 100;
        private const int MorningEnd = 12;
        private const int EveningStart = 20;

        public static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("Примеры if-else");
            Console.WriteLine();

            CheckLevel(LevelCompletion);

            Console.WriteLine();
            ValidateInputForGreeting();

            TrafficLight();

            Console.ReadKey(); 
        }

        // Проверка уровня
        static void CheckLevel(int score)
        {
            while (true)
            {
                Console.Write("Введите ваш уровень: ");
                string input = Console.ReadLine().Trim();

                if (int.TryParse(input, out score))
                {
                    if (score >= LevelCompletion)
                    {
                        Console.WriteLine("Уровень пройден");
                        return;
                    }

                    else
                    {
                        Console.WriteLine("Попробуйте еще раз");
                    }
                }
                else
                {
                    Console.WriteLine("Пожалуйста введите корректное число");
                }

                Console.WriteLine();
            }
        }
        
        // Вывод приветствия в зависимости от времени суток
        static void GreetByTime(int hour)
        {
            
            Console.WriteLine($"Время: {hour}:00");

            if(hour <= MorningEnd)
            {
                Console.WriteLine("Good morning");

            }
            else if (hour < EveningStart)
            {
                Console.WriteLine("Good day");
            }
            else 
            {
                Console.WriteLine("Good evening");
            }

            
        }
        
        static void ValidateInputForGreeting()
        {
            Console.Write("Введите час (0-23): ");
            string value = Console.ReadLine().Trim();

            if (int.TryParse(value, out int hour)&& hour>=0 && hour <=23)
            {
                GreetByTime(hour);
            }
            else
            {
                Console.WriteLine("Некорректное число. Введите число от 0 до 23");
            }
            Console.WriteLine();
        }
            
        // Интерактивный светофор: запршивает цвет и дает команду     
        static void TrafficLight()
        {
            while (true)
            {
                Console.Write("Введите цвет светофора(red/yellow/green): ");
                string? color = Console.ReadLine()?.ToLower()?.Trim();

                Console.WriteLine();

                if (color == "red")
                {
                    Console.WriteLine("Цвет красный: Stop!");
                    return;
                }
                else if (color == "yellow")
                {
                    Console.WriteLine("Цвет желтый: Slow down");
                    return;
                }
                else if (color == "green")
                {
                    Console.WriteLine("Цвет зеленый: Go");
                    return;
                }
                else
                {
                    Console.WriteLine("Color not recognized");
                    return;
                }

            }
        }

    }



}
