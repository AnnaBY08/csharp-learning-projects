﻿using System;

namespace FeetInchesConverter
{
    public class Program
    {

        private const int InchesInFeet = 12;
        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("Конвертер футов в дюймы");
           

            Converter();
        }

        static void Converter()
        {
            bool work = true;

            while (work)
            {

                string value = ShowMenuAndGetChoice();

                switch (value)
                {
                    case "1":
                    ConvertFeetToInches();
                    break;

                    case "2":
                    ConvertInchesToFeet();
                    break;

                    default:
                    Console.WriteLine("Неверный выбор. Введите 1 или 2 ");
                    break;
                }

                work = AskContinue();
            }

        }


        static string ShowMenuAndGetChoice()
        {
            Console.WriteLine();
            Console.WriteLine("1. Футы → Дюймы ");
            Console.WriteLine("2. Дюймы → Футы ");
            Console.Write("Выберите режим (1 или 2): ");
            

            return Console.ReadLine();
        }


        static void ConvertFeetToInches()
        {
            Console.WriteLine();
            Console.Write("Введите количетсво футов: ");
            string number1 = Console.ReadLine();

            if (double.TryParse(number1, out double feet))
            {

                double result = CalculateInches(feet);
                Console.WriteLine();
                Console.WriteLine($"{feet} футов = {result} дюймов ");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ошибка. Введите корректное число");
            }

        }


        static void ConvertInchesToFeet()
        {
            Console.WriteLine();
            Console.Write("Введите количество дюймов: ");
            string number2 = Console.ReadLine();

            if (double.TryParse(number2, out double inches))
            {
                Console.WriteLine();
                double result = CalculateFeet(inches);
                Console.WriteLine($"{inches} дюймов = {result:F2} футов ");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Ошибка. Введите корректное число");
            }


        }
        static double CalculateInches(double feet)
        {
            return feet * InchesInFeet;
        }

        static double CalculateFeet(double inches)
        {
            return inches / InchesInFeet;
        }

        static bool AskContinue()
        {
            while (true)
            {
                Console.WriteLine();
                Console.Write("Продолжить работу? (Введите: да/нет ): ");
                string answer = Console.ReadLine().ToLower().Trim();
                Console.WriteLine();

                if (answer == "нет")
                {
                    Console.WriteLine("Спасибо за использование ковертера!");
                    return false;

                }
                else if (answer == "да")
                {
                    return true;
                }
                else
                {
                    Console.WriteLine("Введите корректное значение");
                    

                }
            }

            
        }
    }

}
