﻿using System;


namespace Инструкция_Switch
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Примеры использования Switch-выражений");
            Console.WriteLine();

            ChooseCategory();
            Console.WriteLine();

            ChooseColor();
            Console.WriteLine();

            
            Console.ReadKey();

        }

        static void ChooseCategory()
        {
            Console.WriteLine("Пример 1. Выберите категорию:");
            Console.WriteLine();
            Console.WriteLine(" 1 - Sport ");
            Console.WriteLine(" 2 - Business");
            Console.WriteLine(" 3 - Technology");
            Console.WriteLine();
            Console.Write (" Ваш выбор: ");
          

            string value = Console.ReadLine();
            bool IsValid = int.TryParse(value, out int choice);

            string result = (IsValid, choice) switch
            {
                (true, 1) => " Вы выбрали категорию: Sport",
                (true, 2) => " Вы выбрали категорию: Business",
                (true, 3) => " Вы выбрали категорию: Technology",
                _ => " Ошибка: введите число от 1 до 3"
            };

            Console.WriteLine(result);
        }


        static void ChooseColor()
        {

            Console.WriteLine("Пример 2. Выбор цвета");
            Console.Write("Введите цвет: red / blue");
           

            string? color = Console.ReadLine().Trim().ToLower() ?? "";

            string message = color switch
            {
                "blue" => "This is blue",
                "red" => "This is red",
                _ => "color not found. Try blue or red."
            };

            Console.WriteLine(message);

        }

    }
}
